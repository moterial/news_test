

<?php $__env->startSection('content'); ?>

<section class="container">
    <div class="row my-3 ms-1">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">主頁</a></li>
              <li class="breadcrumb-item"><a href="#">最新消息</a></li>
              <li class="breadcrumb-item breadcrumb-active" aria-current="page">新聞發佈</li>
            </ol>
        </nav>
    </div>

    <div class="main-content" style="margin-bottom: 10%">
        <div class="row">
            <div class="col-3" >
              <ul class="page-left-menu d-none d-md-block">
                <li><a href="#">樂屋新項目</a></li>
                <li class="left-menu-active"><img src="<?php echo e(asset('image/skip-track.png')); ?>"/><a href="<?php echo e(route('home.index')); ?>">新聞發佈</a></li>

              </ul>
            </div>
            
            <?php if(isset($news)): ?>
            <div class="col-md-9 col-12">
              <p class="title" style="color:#940521;"><?php echo e($news[0]->title); ?></p>
              <div class="row">
                <div class="news-content">
                    <p class="news-title text-center">
                        <strong><u><?php echo e($news[0]->title); ?></u></strong>
                    </p>
                    <p style="font-size: 0.9em;" id='news-des' class='mb-5'>
                        <?php
                            echo nl2br(json_decode($news[0]->content));
                        ?>
                    </p>
                    <?php if(isset($news[0]->link)): ?>
                        <div class="youtube-player mb-5 text-center">
                            <iframe width="80%" height="315" src="<?php echo e(//get the youtube video id from the link
                                'https://www.youtube.com/embed/'.explode('=', $news[0]->link)[1]); ?>" frameborder="0" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    <?php endif; ?>
                    <?php if(isset($news[0]->image)): ?>
                    <div class="image-show row">
                        <?php $__currentLoopData = $news[0]->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-12 d-flex aligns-items-center justify-content-center mb-5">
                                <img src="<?php echo e(asset('uploads/'.$image)); ?>" alt="" class="" style="display: block;
                                max-width:400px;
                                max-height:200px;
                                width: auto;
                                height: auto;">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <?php endif; ?>

                </div>  

              </div>
            </div>
            <?php endif; ?>
           
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<script src="<?php echo e(asset('js/jquery-3.7.0.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        //split the news-des with <br> tag and store in array
        var news_des = $('#news-des').html().split('<br>');
        //remove the <br> tag
        $('#news-des').html('');
        //loop through the array and append the <p> tag to each element
        for(var i = 0; i < news_des.length; i++){
            $('#news-des').append('<p>'+news_des[i]+'</p>');
        }

        
        
    });
</script>


<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_test\resources\views/website/news_detail.blade.php ENDPATH**/ ?>